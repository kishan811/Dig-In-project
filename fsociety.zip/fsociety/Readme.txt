Dig In! Food website

How to run :- Download the zip file. Extract It. Go to fsociety (current) folder , open terminal and 
write command python run.py

Functionalities:- 
Through this website, users can register and subsequently login to place orders from nearby restaurants. 
Restaurant manager can get their restaurants registered on the website. 
After approval from the admin, the restaurant will be added to the list of nearby restaurants and will be visible to the users. 
The restaurant manager can edit their restuarant's menu (change price, add/delete items ) at any time. 
Restaurants can also accept/reject orders. 

Assumptions:- 

Restaurant Registration can only be done by DigIn Admin. For that Restaurant owners have to contact the digin admin separately. 
If user/restaurant owner forgets the password, for that they have to contact the digin admin separately. 
(Contact Details of admin are provided at bottom) 
